package com.fiap.challenge.users.dto;

public record LoginRequestDTO(
	String email, 
	String password
) {}
