package com.fiap.challenge.users.dto;

public record LoginResponseDTO(
	String token
) {}
