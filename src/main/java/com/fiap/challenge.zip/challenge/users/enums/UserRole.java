package com.fiap.challenge.users.enums;

public enum UserRole {
	MASTER,
    ADMIN,
    MECHANIC,
    ATTENDANT,
    CLIENT
}
