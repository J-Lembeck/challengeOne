package com.fiap.challenge.customers.dto;

public record CustomerResumeDTO(String name, String cpfCnpj, String phone, String email) {
}
