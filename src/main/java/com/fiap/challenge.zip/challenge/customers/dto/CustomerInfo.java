package com.fiap.challenge.customers.dto;

import java.util.UUID;

public record CustomerInfo(UUID id, String name) {}
