package com.fiap.challenge.vehicles.dto;

public record VehicleResumeDTO (String brand, String model, Integer year) {
}
