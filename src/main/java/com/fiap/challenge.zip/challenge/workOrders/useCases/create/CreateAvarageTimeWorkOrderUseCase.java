package com.fiap.challenge.workOrders.useCases.create;

import com.fiap.challenge.workOrders.entity.WorkOrderAvarageTime;

public interface CreateAvarageTimeWorkOrderUseCase {
    void execute(WorkOrderAvarageTime workOrderAvarageTime);
}
