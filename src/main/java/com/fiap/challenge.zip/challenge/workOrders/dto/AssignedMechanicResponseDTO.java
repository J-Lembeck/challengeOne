package com.fiap.challenge.workOrders.dto;

public record AssignedMechanicResponseDTO(Boolean success) {
}
